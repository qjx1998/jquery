var apikey,id;
$(function(){
	//获取当前页面参数和apikey
	var theRequest =GetRequest();
	id = theRequest.id;
	apikey = theRequest.apikey;
	category_type = theRequest.category_type;

	$("input[name='city']").val("湘吉");
	$("input[name='administration']").val("湘西自治州市场监督管理局");
	task_detail();
	clauselist();
	// clauselist2();

	$('#clauselist').on("change", function(){
		clausedetail(this.value)
	})
	$('#basis_tiao').on("change", function(){
		clausedetail2(this.value)
	})
})

//监管人员---立即执行任务-- 一般问题
var questionslist;
function accepttask_questionslist(){
	var date = $("#autographdate_year").val()+'/'+$("#autographdate_month").val()+'/'+$("#autographdate_day").val()
	var time=Date.parse(new Date(date))/1000;
	$("#date").val(time)
	var date1 = $("#ordery").val()+'/'+$("#orderm").val()+'/'+$("#orderd").val();
	var time1=Date.parse(new Date(date1))/1000;
	$("#orderdate").val(time1)

	var formObject = {};
	var list = {};
	var formArray =$("#missionInfo").serializeArray();
	var flag=1;
	$.each(formArray,function(i,item){
		if(item.value==""){
			flag=0
			if(item.name=="checkname"||item.name=="becheckname"){
				alert("请确认签名")
			}else{
				alert("请填写完整数据")
			}
			return false;
		}else{
			formObject[item.name] = item.value;
		}

	});
	if(flag==1){
		formObject.tiao_text=$("#tiao_text").html();
		formObject.regulations=$("#regulations").html();
		list["questionslist"] = formObject
		questionslist=JSON.stringify(list)
		console.log("questionslist",questionslist)
		$.ajax({
			type:"post",
			url :requestUrl+api.accepttask_questionslist,
			data:{
				id:id,
				category_type:category_type,
				questionslist:questionslist
			},
			headers:{
				apikey:apikey,
				Accept: "application/json; charset=utf-8"
			},
			async: true,
			dataType: "json",
			success: function(data){
				if(data.code==1){
					alert("提交成功");
					back()
				}else{
					alert("提交失败："+data.msg)
				}
			},
			error:function(error){
				alert("提交失败："+error.msg)
			}
		})
	}

}

//监管人员---任务详情
function task_detail(){
	$.ajax({
		type:"post",
		url :requestUrl+api.task_detail,
		data:{
			id:id
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"任务详情")
			if(data.code==1){
				var res = data.data;
				$("textarea[name='question']").val(res.recorddetail)
				$("input[name='no_text']").val(res.company)
				$("#no_text").html(res.company)
			}
		}
	})
}

//特种设备安全监察指令书填写规范（特种设备安全法）列表
function clauselist(){
	$.ajax({
		type:"post",
		url :requestUrl+api.clauselist,
		data:{
			 type_id:1
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			if(data.code==1){
				var html = "";
				var list = data.data;
				for(var i=0;i<list.length;i++){
					html+='<option value="'+list[i].id+'">'+list[i].tiao + '</option><option disabled style="height: 20px;width: 100px;font-size: 10px">' + list[i].behavior + '</option>'
				}
				$("#clauselist").html(html)
				$("#clauselist").attr("value",list[0].id);
				clausedetail(list[0].id)
			}
		}
	})
}
// function clauselist2(){
// 	$.ajax({
// 		type:"post",
// 		url :requestUrl+api.clauselist,
// 		data:{
// 			 type_id:2
// 		},
// 		headers:{
// 			apikey:apikey,
// 			Accept: "application/json; charset=utf-8"
// 		},
// 		async: true,
// 		dataType: "json",
// 		success: function(data){
// 			if(data.code==1){
// 				var html = "";
// 				var list = data.data;
// 				for(var i=0;i<list.length;i++){
// 					html+='<option style="display: block;position: relative" value="'+list[i].id+'">'+ list[i].tiao + '</option><option disabled>' + list[i].behavior + '</option>'
// 				}
// 				$("#basis_tiao").html(html);
// 				$("#basis_tiao").attr("value",list[0].id);
// 				clausedetail2(list[0].id);
// 			}
// 		}
// 	})
// }
function clausedetail(num){
	console.log(num)
	$.ajax({
		type:"post",
		url :requestUrl+api.clausedetail,
		data:{
			id:num
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"clausedetail")
			if(data.code==1){
				$("#tiao_text").html(data.data.behavior);
				$("#basis_tiao").html(data.data.basis_tiao);
				$("#regulations").html(data.data.measures);
				$("input[name='tiao_text']").val(data.data.behavior);
				$("input[name='basis_tiao']").val(data.data.basis_tiao);
				$("input[name='regulations']").val(data.data.measures);
			}

		}
	})
}
// function clausedetail2(num){
// 	$.ajax({
// 		type:"post",
// 		url :requestUrl+api.clausedetail,
// 		data:{
// 			id:num
// 		},
// 		headers:{
// 			apikey:apikey,
// 			Accept: "application/json; charset=utf-8"
// 		},
// 		async: true,
// 		dataType: "json",
// 		success: function(data){
// 			if(data.code==1){
// 				$("#tiao_text").html(data.data.behavior);
// 				$("#basis_tiao").html(data.data.basis_tiao);
// 				$("#regulations").html(data.data.measures);
// 			}
//
// 		}
// 	})
// }