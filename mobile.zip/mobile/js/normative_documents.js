var apikey,id;
$(function(){
	//获取当前页面参数和apikey
	var theRequest =GetRequest();
	id = theRequest.id;
	apikey = theRequest.apikey;
	category_type = theRequest.category_type
	//获取任务详情
	task_detail()
	
})

//监管人员---立即执行任务--检查记录提交
var wenshulist;
function accepttask_wenshulist(){
	var date = $("#autographdate_year").val()+'/'+$("#autographdate_month").val()+'/'+$("#autographdate_day").val()
	var time=Date.parse(new Date(date))/1000;
	$("#checkdate").val(time)
	var formObject = {};
	var list = {};
	var formArray =$("#form").serializeArray();
	var flag=1;
	$.each(formArray,function(i,item){
		formObject[item.name] = item.value;
		if(item.value==""){
			flag=0
			if(item.name=="partyautograph"||item.name=="witnessautograph"||item.name=="checkautograph"){
				alert("请确认签名")
			}else{
				alert("请填写完整数据")
			}
			return false;
		}
	});
	if(flag==1){
		formObject.task_id=id;
		list["wenshulist"] = formObject
		console.log(formObject)
		wenshulist=JSON.stringify(list)
		
		console.log("wenshulist",wenshulist)
		
		$.ajax({
			type:"post",
			url :requestUrl+api.accepttask_wenshulist,
			data:{
				id:id,
				category_type:category_type,
				wenshulist:wenshulist
			},
			headers:{
				apikey:apikey,
				Accept: "application/json; charset=utf-8"
			},
			async: true,
			dataType: "json",
			success: function(data){
				console.log(data,"检查记录提交")
				if(data.code==1){
					alert("提交成功");
					back()
				}else{
					alert("提交失败："+data.msg)
				}
			},
			error:function(error){
				alert("提交失败："+error.msg)
			}
		})
	}
}

//监管人员---任务详情
function task_detail(){
	$.ajax({
		type:"post",
		url :requestUrl+api.task_detail,
		data:{
			id:id
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"任务详情")
			if(data.code==1){
				var res = data.data;
				$("input[name='stardate']").val(res.stardate)
				$("input[name='enddate']").val(res.enddate)
				$("input[name='address']").val(res.address)
				$("input[name='checkname']").val(res.checkname)
				$("input[name='checkname1']").val(res.checkname1)
				$("input[name='checknameno']").val(res.checknameno)
				$("input[name='checknameno1']").val(res.checknameno1)
				$("input[name='companyaddress']").val(res.companyaddress)
				$("input[name='legalname']").val(res.legalname)
				$("input[name='linkmobile']").val(res.linkmobile)
				$("input[name='linkaddress']").val(res.companyaddress)
			}
			
		}
	})
}