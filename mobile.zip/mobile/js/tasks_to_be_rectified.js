var apikey,id,bhId;
$(function(){
	//获取当前页面参数和apikey
	var theRequest =GetRequest();
	id = theRequest.id;
	apikey = theRequest.apikey;
	category_type = theRequest.category_type;
	
	modifydetail()
})

//电梯使用单位-待整改详情-检查完成
function modifyautograph(){
	var date = $("#autographdate_year").val()+'/'+$("#autographdate_month").val()+'/'+$("#autographdate_day").val()
	var time=Date.parse(new Date(date))/1000;
	$("#date").val(time)
	
	var formObject = {};
	var formArray =$("#missionInfo").serializeArray();
	var flag=1;
	$.each(formArray,function(i,item){
		if(item.value==""){
			flag=0
			if(item.name=="checkname"||item.name=="becheckname"){
				alert("请确认签名")
			}else{
				alert("请填写完整数据")
			}
			return false;
		}else{
			formObject[item.name] = item.value;
		}
		
	});
	if(flag==1){
		$.ajax({
			type:"post",
			url :requestUrl+api.modifyautograph,
			data:{
				id:bhId,
				becheckname:$("input[name='becheckname']").val(),
				date:$("#date").val()
			},
			headers:{
				apikey:apikey,
				Accept: "application/json; charset=utf-8"
			},
			async: true,
			dataType: "json",
			success: function(data){
				if(data.code==1){
					alert("提交成功");
					back()
				}else{
					alert("提交失败："+data.msg)
				}
			},
			error:function(error){
				alert("提交失败："+error.msg)
			}
		})
	}
	
}

//监管人员---任务详情
function modifydetail(){
	$.ajax({
		type:"post",
		url :requestUrl+api.modifydetail,
		data:{
			id:id,
			category_type:category_type,
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"任务详情")
			if(data.code==1){
				var res = data.data;
				bhId = res.id;
				var date = new Date(res.orderdate*1000);
				var ordery = date.getFullYear();
				var orderm = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1);
				var orderd = (date.getDate() < 10 ? '0'+date.getDate() : date.getDate());
				
				$("input[name='city']").val(res.city);
				$("input[name='nian']").val(res.nian);
				$("input[name='no']").val(res.no);
				$("input[name='no_text']").val(res.no_text);
				$("textarea[name='question']").val(res.question);
				$("input[name='tiao']").val(res.tiao);
				$("textarea[name='tiao_text']").val(res.tiao_text);
				$("input[name='basis_tiao']").val(res.basis_tiao);
				$("textarea[name='regulations']").val(res.regulations);
				$("input[name='orderdate']").val(res.orderdate);
				$("input[name='ordery']").val(ordery);
				$("input[name='orderm']").val(orderm);
				$("input[name='orderd']").val(orderd);
				
				$("input[name='checkname']").val(res.checkname);
				$("input[name='administration']").val(res.administration);
				$("textarea[name='accident']").val(res.accident);
				$("input[name='court']").val(res.court);
				
				$("input[name='checkname']").val(res.checkname);
				var i = new Image();
				i.src = res.checkname;
				$(i).appendTo($("#image")) // append the image (SVG) to DOM.
			}
			
		}
	})
}