var apikey,id,bhid;
$(function(){
	//获取当前页面参数和apikey
	var theRequest =GetRequest();
	id = theRequest.id;
	apikey = theRequest.apikey;
	category_type = theRequest.category_type
	// alert(category_type)
	//获取任务详情
	taskdetail()
	
})

//监管人员---立即执行任务--检查记录提交
var checklist;
function taskautograph(){
	var date = $("#autographdate_year").val()+'/'+$("#autographdate_month").val()+'/'+$("#autographdate_day").val()
	var time=Date.parse(new Date(date))/1000;
	$("#autographdate").val(time)
	var formObject = {};
	var  list = {};
	var formArray =$("#forminfo").serializeArray();
	var flag=1;
	$.each(formArray,function(i,item){
		formObject[item.name] = item.value;
		if(item.value==""){
			if(item.name=="check_text"||item.name=="register_code"){
				console.log(item.name)
				flag=0
				alert("请填写完整数据");
				return false;
			}
		}
	});
	if(flag==1){
		list["checklist"] = formObject
		console.log(list,"**************")
		checklist=JSON.stringify(list)
		console.log(checklist)
		$.ajax({
			type:"post",
			url :requestUrl+api.taskautograph,
			data:{
				id:bhid,
				opinion:$("textarea[name='opinion']").val(),
				autograph:$("input[name='autograph']").val(),
				autographdate:$("input[name='autographdate']").val()
			},
			headers:{
				apikey:apikey,
				Accept: "application/json; charset=utf-8"
			},
			async: true,
			dataType: "json",
			success: function(data){
				console.log(data,"检查记录提交")
				if(data.code==1){
					alert("提交成功");
					back()
				}else{
					alert("提交失败："+data.msg)
				}
			},
			error:function(error){
				alert("提交失败："+error.msg)
			}
		})
	}
}

//电梯使用单位-待整改详情
function taskdetail(){
	$.ajax({
		type:"post",
		url :requestUrl+api.taskdetail,
		data:{
			id: id,
			category_type: category_type
		},
		headers:{
			apikey: apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"电梯使用单位-待整改详情") 
			if(data.code==1){
				var res = data.data;
				bhid = res.id;
				var date = new Date(res.recorddate*1000);
				var recordy = date.getFullYear();
				var recordm = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1);
				var recordd = (date.getDate() < 10 ? '0'+date.getDate() : date.getDate());
				$("input[name='type_id']").val(res.type_id)
				$("input[name='equipment_type']").val(res.equipment_type)
				$(":radio[name='check_type'][value='" + res.check_type + "']").prop("checked", "checked");
				$(":radio[name='check_id'][value='" + res.check_id + "']").prop("checked", "checked");
				$("textarea[name='check_text']").val(res.check_text)
				$("textarea[name='register_code']").val(res.register_code)
				$(":radio[name='is_question1'][value='" + res.is_question1 + "']").prop("checked", "checked");
				$("textarea[name='is_question1_text']").val(res.is_question1_text)
				$(":radio[name='is_question2'][value='" + res.is_question2 + "']").prop("checked", "checked");
				$("textarea[name='is_question2_text']").val(res.is_question2_text)
				$(":radio[name='is_question3'][value='" + res.is_question3 + "']").prop("checked", "checked");
				$("textarea[name='is_question3_text']").val(res.is_question3_text)
				$(":radio[name='is_question4'][value='" + res.is_question4 + "']").prop("checked", "checked");
				$("textarea[name='is_question4_text']").val(res.is_question4_text)
				$(":radio[name='is_question5'][value='" + res.is_question5 + "']").prop("checked", "checked");
				$("textarea[name='is_question5_text']").val(res.is_question5_text)
				$(":radio[name='is_question6'][value='" + res.is_question6 + "']").prop("checked", "checked");
				$("textarea[name='is_question6_text']").val(res.is_question6_text)
				$(":radio[name='is_question7'][value='" + res.is_question7 + "']").prop("checked", "checked");
				$("textarea[name='is_question7_text']").val(res.is_question7_text)
				$(":radio[name='is_question8'][value='" + res.is_question8 + "']").prop("checked", "checked");
				$("textarea[name='is_question8_text']").val(res.is_question8_text)
				$(":radio[name='is_question9'][value='" + res.is_question9 + "']").prop("checked", "checked");
				$("textarea[name='is_question9_text']").val(res.is_question9_text)
				$(":radio[name='is_question10'][value='" + res.is_question10 + "']").prop("checked", "checked");
				$("textarea[name='is_question10_text']").val(res.is_question10_text)
				$("textarea[name='supplement']").val(res.supplement)
				$("textarea[name='measures']").val(res.measures)
				$("input[name='recordautograph']").val(res.recordautograph)

				$("input[name='recorddate']").val(res.recorddate)
				$("#recordy").val(recordy)
				$("#recordm").val(recordm)
				$("#recordd").val(recordd)
				$("input[name='stardate']").val(res.stardate)
				$("input[name='enddate']").val(res.enddate)
				$("input[name='company']").val(res.company)
				$("input[name='companyaddress']").val(res.companyaddress)
				$("input[name='legalname']").val(res.legalname)
				$("input[name='linkname']").val(res.linkname)
				$("input[name='linkmobile']").val(res.linkmobile)
				$("input[name='linkpost']").val(res.linkpost)

				$("#num").html(res.num)
				$("#usecargo").html(res.usecargo)
				$("#useescalator").html(res.useescalator)
				$("#useelevator").html(res.useelevator)
				$("#usesidewalk").html(res.usesidewalk)
				$("#stopcargo").html(res.stopcargo)
				$("#stopescalator").html(res.stopescalator)
				$("#stoplevator").html(res.stoplevator)
				$("#stopsidewalk").html(res.stopsidewalk)

				$("#total").html(res.num)

				$("#checkautograph").val(res.checkautograph)
				var i = new Image();
				i.src = res.checkautograph;
				$(i).appendTo($("#image2"))


				$("#recordautograph").val(res.recordautograph)
				var i = new Image();
				i.src = res.recordautograph;
				$(i).appendTo($("#image3")) // append the image (SVG) to DOM.

			}else{
				alert("获取失败："+data.msg)
			}

		}
	})
}