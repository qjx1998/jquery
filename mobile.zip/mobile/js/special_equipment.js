var apikey,id,elevators,category_type;
$(function(){
	//获取当前页面参数和apikey
	var theRequest =GetRequest();
	id = theRequest.id;
	apikey = theRequest.apikey;
	elevators = theRequest.elevators;

	category_type = theRequest.category_type
	console.log(category_type)
	$('.level').val(elevators);
	// alert(category_type)
	//获取任务详情
	task_detail()
	
})

//监管人员---立即执行任务--检查记录提交
var checklist;
function accepttask_checklist(){
	console.log(category_type)
	var date = $("#recordy").val()+'/'+$("#recordm").val()+'/'+$("#recordd").val()
	var time=Date.parse(new Date(date))/1000;
	$("#recorddate").val(time)
	var formObject = {};
	var  list = {};
	var formArray =$("#forminfo").serializeArray();
	var flag=1;
	$.each(formArray,function(i,item){
		formObject[item.name] = item.value;
		if(item.value==""){
			if(item.name=="check_text"||item.name=="register_code"){
				console.log(item.name)
				flag=0
				alert("请填写完整数据");
				return false;
			}
		}
	});
	if(flag==1){
		list["checklist"] = formObject
		console.log(list,"**************")
		checklist=JSON.stringify(list)

		$.ajax({
			type:"post",
			url :requestUrl+api.accepttask_checklist,
			data:{
				id:id,
				category_type: category_type,
				checklist:checklist
			},
			headers:{
				apikey: apikey,
				Accept: "application/json; charset=utf-8"
			},
			async: true,
			dataType: "json",
			success: function(data){
				console.log(data,"检查记录提交")
				if(data.code==1){
					alert("提交成功");
					back()
				}else{
					alert("提交失败："+data.msg)
				}
			},
			error:function(error){
				alert("提交失败："+error.msg)
			}
		})
	}
}

//监管人员---任务详情
function task_detail(){
	$.ajax({
		type:"post",
		url :requestUrl+api.task_detail,
		data:{
			id: id
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"任务详情") 
			if(data.code==1){
				// alert("获取任务详情成功")
				$("input[name='stardate']").val(data.data.stardate)
				$("input[name='enddate']").val(data.data.enddate)
				$("input[name='company']").val(data.data.company)
				
				$("input[name='companyaddress']").val(data.data.companyaddress)
				$("input[name='legalname']").val(data.data.legalname)
				$("input[name='linkname']").val(data.data.linkname)
				$("input[name='linkmobile']").val(data.data.linkmobile)
				$("input[name='linkpost']").val(data.data.linkpost)
				$("#usecargo").html(data.data.usecargo)
				$("#useescalator").html(data.data.useescalator)
				$("#useelevator").html(data.data.useelevator)
				$("#usesidewalk").html(data.data.usesidewalk)
				$("#stopcargo").html(data.data.stopcargo)
				$("#stopescalator").html(data.data.stopescalator)
				$("#stoplevator").html(data.data.stoplevator)
				$("#stopsidewalk").html(data.data.stopsidewalk)
				
				$("#total").html(data.data.num)
				
			}else{
				alert("获取失败："+data.msg)
			}
			
		}
	})
}