var apikey,id;
$(function () {
    var theRequest = GetRequest();
    apikey = theRequest.apikey;
    id = theRequest.id;
    getData();
})

function getData() {
    $.ajax({
        type:"post",
        url :requestUrl + api.duty_details,
        data:{
            id: id
        },
        headers:{
            apikey: apikey,
            Accept: "application/json; charset=utf-8"
        },
        async: true,
        dataType: "json",
        success: function(res){
            console.log(res,"任务详情")
            var data = res.data;
            var checkinfo,questioninfo;
            var duty_list;
            if(data){
                checkinfo = data.checkinfo;
                questioninfo = data.questioninfo;
                if(data.type_id == 1){
                    duty_list = '日常监督'
                }else if(data.type_id == 2){
                    duty_list = '双随机日常监督'
                }else{
                    duty_list = '专项检查'
                }

            }
            if(res.code==1){

                $('.ele_type').html(duty_list);
                $('.ele_date').html(data.week + " " + data.stardate);
                $('.ele_menage').html(data.company);
                $('.ele_hu').html(data.companyaddress);
                $('.ele_num').html(data.num);
                $('.check_man').html(data.username);
                $('.ele_phone').html(data.phone);
                $('.ele_pos').html(data.signaddress);
                $('.ele_times').html(data.signtime);
                

                $(":radio[name='type1'][value='" + checkinfo.check_type + "']").prop("checked", "checked");
                $(".sp-check5").html(data.stardate + "至"+ data.enddate);
                $('.col-name').html(data.company);
                $('.com-man').html(data.legalname);
                $('.com-addr').html(data.address);
                $('.led-man').html(data.linkname);
                $('.led-job').html(data.linkpost);
                $('.link-tel').html(data.linkmobile);
                $(":checkbox[name='type'][value='" + checkinfo.check_id + "']").prop("checked", "checked");
                $('.element-nums').html(data.num);
                $('.ele1').html(data.useelevator);
                $('.ele2').html(data.useescalator);
                $('.ele3').html(data.usesidewalk);
                $('.ele4').html(data.usecargo);
                $('.ele5').html(data.stoplevator);
                $('.ele6').html(data.stopescalator);
                $('.ele7').html(data.stopsidewalk);
                $('.ele8').html(data.stopcargo);
                let dom = '',dom2 = '',dom3 = '';
                for(let i = 0; i < data.elevator_list.length; i++){
                   dom += '<div class="add-border">' + data.elevator_list[i].name + '</div>'
                }
                for(let i = 0; i < data.elevator_list.length; i++){
                    dom2 += '<div class="add-border">' + data.elevator_list[i].numberno + '</div>'
                    dom3 +=','+data.elevator_list[i].numberno;
                }

                $('.ele-select').html(dom3);

                $('.chou-eq').append(dom);
                $('.chou-num').append(dom2);
                $(":checkbox[name='name1'][value='" + checkinfo.is_question1 + "']").prop("checked", "checked");
                $(":checkbox[name='name2'][value='" + checkinfo.is_question2 + "']").prop("checked", "checked");
                $(":checkbox[name='name3'][value='" + checkinfo.is_question3 + "']").prop("checked", "checked");
                $(":checkbox[name='name4'][value='" + checkinfo.is_question4 + "']").prop("checked", "checked");
                $(":checkbox[name='name5'][value='" + checkinfo.is_question5 + "']").prop("checked", "checked");
                $(":checkbox[name='name6'][value='" + checkinfo.is_question6 + "']").prop("checked", "checked");
                $(":checkbox[name='name7'][value='" + checkinfo.is_question7 + "']").prop("checked", "checked");
                $(":checkbox[name='name8'][value='" + checkinfo.is_question8 + "']").prop("checked", "checked");
                $(":checkbox[name='name9'][value='" + checkinfo.is_question9 + "']").prop("checked", "checked");
                $(":checkbox[name='name10'][value='" + checkinfo.is_question10 + "']").prop("checked", "checked");
                $(":checkbox[name='name11'][value='" + checkinfo.measures + "']").prop("checked", "checked");
                $('.sp-main-cont').html(checkinfo.opinion);
                $('.link-name').html('<img src=" ' + checkinfo.autograph + ' " style="height: 40px">');
                $('.link-date').html(checkinfo.autographdate);
                $('.check_man').html('<img src=" ' + checkinfo.checkautograph + ' " style="height: 40px">');
                $('.elv_man').html('<img src=" ' + checkinfo.recordautograph + ' " style="height: 40px">');
                $('.elv_date').html(checkinfo.signtime);
                $('.mes-city').html(questioninfo.city);
                $('.nes-year').html(questioninfo.nian);
                $('.nes-hao').html(questioninfo.no);
                $('.inner').html(questioninfo.no_text);
                $('.question').html(questioninfo.question);
                $('.sectiy').html(questioninfo.tiao);
                $('.tiao_text').html(questioninfo.tiao_text);
                $('.equip').html(questioninfo.basis_tiao);
                $('.regulations').html(questioninfo.regulations);
                $('.datess').html(questioninfo.orderdate);
                $('.yinhuan').html(questioninfo.accident);
                $('.fayuan').html(questioninfo.administration);
                $('.where').html(questioninfo.court);
                $('.danwei').html(questioninfo.orderdate);
                $('.seal_time').html(questioninfo.date);
                $('.give_name').html(questioninfo.date);
                $('.check_names').html('<img src=" ' + questioninfo.checkname + ' " style="height: 40px">');
                $('.danwei').html('<img src=" ' + questioninfo.becheckname + ' " style="height: 40px">');

                $('.text1').val(checkinfo.is_question1_text);
                $('.text2').val(checkinfo.is_question2_text);
                $('.text3').val(checkinfo.is_question3_text);
                $('.text4').val(checkinfo.is_question4_text);
                $('.text5').val(checkinfo.is_question5_text);
                $('.text6').val(checkinfo.is_question6_text);
                $('.text7').val(checkinfo.is_question7_text);
                $('.text8').val(checkinfo.is_question8_text);
                $('.text9').val(checkinfo.is_question9_text);
                $('.text10').val(checkinfo.is_question10_text);

            }

        }
    })
}