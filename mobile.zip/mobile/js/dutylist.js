var apikey,typeId = '1',page= 1,data2 = [];

$(function(){
    //获取当前页面参数和apikey
    var theRequest =GetRequest();
    apikey = theRequest.apikey;
    //获取任务详情
    task_read()
    $('.nav-top').delegate('div','click',function(e){
        $(e.target).siblings().removeClass('selected');
        $(e.target).addClass('selected');
        console.log(e.target.innerText)
        if(e.target.innerText == '双随机监管'){
            typeId = '2';
            data2 = [];
            task_read();
        }else if(e.target.innerText == '日常任务'){
            typeId = '1';
            data2 = [];
            task_read();
        }else if(e.target.innerText == '专项检查'){
            typeId = '3';
            data2 = [];
            task_read();
        }

    })
})

function task_read(){
    $.ajax({
        url: requestUrl + api.un_read,
        headers: {
            apikey: apikey,
            Accept: "application/json; charset=utf-8"
        },
        type: 'post',
        data: { type_id: typeId,page: page },
        dataType: 'json',
        success: function (res) {
            // console.log(res)
            var doms = '';
            let data = res.data;
            console.log(data)
            if(res.code != 0){
                data2 = data2.concat(data);
                console.log(data2)
            }
            if (data2.length > 0){
                console.log(data2);
                $('.nodata').hide();

                for(let i = 0; i < data2.length; i++){
                    doms += "<div class=\"duty-cont \" onclick='ticket(" + data2[i].id + ")'>\n" +
                        "        <div class=\"duty-name\">监管人:" + data2[i].username + "</div>\n" +
                        "        <div class=\"duty-name\">电话:" + data2[i].phone + "</div>\n" +
                        "        <div><span class=\"duty-span\"><img src=\"../img/dates.png\" class=\"dates\"></span>任务下发时间：<span class=\"check-date\">"+ data2[i].creattime +"</span></div>\n" +
                        "        <div><span class=\"duty-span\"><img src=\"../img/pos.png\" class=\"dates\"></span>使用单位:<span class=\"hu-place\">" + data2[i].company + "</span></div>\n" +
                        "        <div><span class=\"duty-span\"><img src=\"../img/binds.png\" class=\"dates\"></span>电梯位置:<span class=\"check-type\">" + data2[i].companyaddress + "</span></div>\n" +
                        "    </div>"
                }
                $('.sum-cont').html(doms)
                page ++;
            }else{
                let doms = "<div class='nodata'>暂无数据</div>"
                $('.duty-cont').hide();
                $('.sum-cont').html(doms);
            }
        }
    })
}

function ticket(param) {
    $(window).attr('location','http://dianti.wqitong.cn/mobile/html/unread.html?apikey='+ apikey + '&id=' + param + "&category_type=" + typeId);
}

var time = 0;
var meter;
$(window).scroll(function (event) {
    var wScrollY = window.scrollY; // 当前滚动条位置
    var wInnerH = window.innerHeight; // 设备窗口的高度（不会变）
    var bScrollH = document.body.scrollHeight; // 滚动条总高度

    if (wScrollY + wInnerH >= bScrollH) {

        if(time != 0){

        }else{
            
            task_read();
            time = 2000
            meter = setTimeout(function clert() {
                time = 0
            },time)
        }
    }
});

