var apikey,type,rev_img,stat,type = '1',page = 1,data2 = [];

$(function(){
    //获取当前页面参数和apikey
    var theRequest = GetRequest();
    apikey = theRequest.apikey;
    type = theRequest.type;
    rev_img = 'gou';
    rev_img2 = 'wrong';
    stat = "待审核";
    //获取任务详情
    task_review()
})

function task_review(){
    $.ajax({
        url: requestUrl + api.un_review,
        headers: {
            apikey: apikey,
            Accept: "application/json; charset=utf-8"
        },
        type: 'post',
        data: { type: type,page: page },
        dataType: 'json',
        success: function (res) {
            var doms = '';
            let data = res.data;
            if(res.code != 0){
                data2 = data2.concat(data);
                console.log(data2)
            }
            if (data2.length > 0){
                $('.nodata').hide();
                for(let i = 0; i < data2.length; i++){
                    doms += "<div class=\"duty-cont\" onclick='ticketTo(" + data2[i].id + ")'>\n" +
                        "            <div class=\"rev-icon\"></div>\n" +
                        "            <div class=\"duty-name\">执法人:" + data2[i].username + "</div>\n" +
                        "            <div class=\"duty-name rev-tell\">电话:" + data2[i].phone + "</div>\n" +
                        "            <div style=\"margin-top: 20px\"><span class=\"duty-span\"><img src=\"../img/dates.png\" class=\"dates\"></span>任务下发时间：<span>"+ data2[i].creattime +"</span></div>\n" +
                        "            <div><span class=\"duty-span\"><img src=\"../img/pos.png\" class=\"dates\"></span><span class=\"hu-place\">" + data2[i].companyaddress + "</span></div>\n" +
                        "            <div style='height: 55px'><span class=\"duty-span\"><img src=\"../img/binds.png\" class=\"dates\"></span>使用单位:" + data2[i].company + "</div>\n" +
                        "            <div style='height: 55px'><span class=\"duty-span\"><img src=\"../img/binds.png\" class=\"dates\"></span>检查内容:" + data2[i].content + "</div>\n" +
                        "        </div>"
                }
                $('.sum-cont').html(doms);
                page ++;
            }else{
                let doms = "<div class='nodata'>暂无数据</div>"
                $('.duty-cont').hide();
                $('.sum-cont').html(doms);
            }

            if(type == '1'){
                console.log(1)
                $('.rev-icon').html('<img src="../img/gou.png" class="dates">'+'待审核');
                $('title').html('待审核');
            }else if(type == '2'){
                console.log(2)
                $('.rev-icon').html('<img src="../img/gou.png" class="dates">'+'已完成');
                $('title').html('已完成');
            }else if(type == '3'){
                console.log(3)
                $('.rev-icon').html('<img src="../img/wrong.png" class="dates">'+'未通过');
                $('title').html('未通过');
            }
        }
    })
}
function ticketTo(param) {
    console.log(param)
    $(window).attr('location','http://dianti.wqitong.cn/mobile/html/mission_details_info.html?apikey='+ apikey + '&id=' + param);
}

var time = 0;
var meter;
$(window).scroll(function (event) {
    var wScrollY = window.scrollY; // 当前滚动条位置
    var wInnerH = window.innerHeight; // 设备窗口的高度（不会变）
    var bScrollH = document.body.scrollHeight; // 滚动条总高度

    if (wScrollY + wInnerH >= bScrollH) {

        if(time != 0){

        }else{
            task_review();
            time = 2000
            meter = setTimeout(function clert() {
                time = 0
            },time)
        }
    }
});