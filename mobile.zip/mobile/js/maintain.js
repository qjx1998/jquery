

function getData() {
    $.ajax({
        url: requestUrl + api.ele_list_detail,
        headers: {
            apikey: apikey,
            Accept: "application/json; charset=utf-8"
        },
        data: { id: id },
        type: 'post',
        dataType: 'json',
        success: function (res) {
            let data = res.data;
            console.log(res)
            if (data) {

                $('.username').html(data.name);
                $('.elv-code').html(data.numberno);
                $('.elv-place').html(data.model_type);
                $('.timers').html(data.branchoffice);
                $('input[name="is_question0"][value=' + data.is_question1 + ']').prop("checked", true);
                $('input[name="is_question1"][value=' + data.is_question2 + ']').prop("checked", true);
                $('input[name="is_question2"][value=' + data.is_question3 + ']').prop("checked", true);
                $('input[name="is_question3"][value=' + data.is_question4 + ']').prop("checked", true);
                $('input[name="is_question4"][value=' + data.is_question5 + ']').prop("checked", true);
                $('input[name="is_question5"][value=' + data.is_question6 + ']').prop("checked", true);
                $('input[name="is_question6"][value=' + data.is_question7 + ']').prop("checked", true);
                $('input[name="is_question7"][value=' + data.is_question8 + ']').prop("checked", true);
                $('input[name="is_question8"][value=' + data.is_question9 + ']').prop("checked", true);
                $('input[name="is_question9"][value=' + data.is_question10 + ']').prop("checked", true);
                $('input[name="is_question10"][value=' + data.is_question11 + ']').prop("checked", true);
                $('input[name="is_question11"][value=' + data.is_question12 + ']').prop("checked", true);
                $('input[name="is_question12"][value=' + data.is_question13 + ']').prop("checked", true);
                $('input[name="is_question13"][value=' + data.is_question14 + ']').prop("checked", true);
                $('input[name="is_question14"][value=' + data.is_question15 + ']').prop("checked", true);
                $('input[name="is_question15"][value=' + data.is_question16 + ']').prop("checked", true);
                $('input[name="is_question16"][value=' + data.is_question17 + ']').prop("checked", true);
                $('input[name="is_question17"][value=' + data.is_question18 + ']').prop("checked", true);
                $('input[name="is_question18"][value=' + data.is_question19 + ']').prop("checked", true);
                $('input[name="is_question19"][value=' + data.is_question20 + ']').prop("checked", true);
                $('input[name="is_question20"][value=' + data.is_question21 + ']').prop("checked", true);
                $('input[name="is_question21"][value=' + data.is_question22 + ']').prop("checked", true);
                $('input[name="is_question22"][value=' + data.is_question23 + ']').prop("checked", true);
                $('input[name="is_question23"][value=' + data.is_question24 + ']').prop("checked", true);
                $('input[name="is_question24"][value=' + data.is_question25 + ']').prop("checked", true);
                $('input[name="is_question25"][value=' + data.is_question26 + ']').prop("checked", true);
                $('input[name="is_question26"][value=' + data.is_question27 + ']').prop("checked", true);
                $('input[name="is_question27"][value=' + data.is_question28 + ']').prop("checked", true);
                $('input[name="is_question28"][value=' + data.is_question29 + ']').prop("checked", true);
                $('input[name="is_question29"][value=' + data.is_question30 + ']').prop("checked", true);
                $('input[name="is_question30"][value=' + data.is_question31 + ']').prop("checked", true);
                $('.record_per_input0').html('<img src="' + data.weibaosign + '" style="height: 50px">');
                $('.record_per_input1').html(data.weibaodate);
                $('.record_per_input2').html(data.weibaoproposal);
                $('.record_per_input3').html(data.chage);
            }
        }
    })
}