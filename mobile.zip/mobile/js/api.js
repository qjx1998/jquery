var requestUrl = "http://dianti.wqitong.cn/api/";
var api = {
	login: "auth/login.html", //监管人员登陆
	user: "user/index.html", //退出登录
	out: "user/out.html", //个人信息
	avatar: "user/avatar.html", //修改头像
	location: "user/location.html", //用户上传地理位置
	task: "user/task.html", //移动监管人员菜单页
	do_task: "user/do_task.html", //监管人员---待办任务
	task_detail: "user/task_detail.html", //监管人员---任务详情
	accepttask: "user/accepttask.html", //监管人员---立即执行任务
	accepttask: "user/taskconfirm.html", //监管人员---其他（未审核待审核已完成）
	accepttask: "user/taskconfirm.html", //任务执行详情电梯使用单位(电梯使用单位---监管任务确认)
	accepttask_checklist:"user/accepttask_checklist.html",//监管人员---立即执行任务--检查记录提交
	accepttask_wenshulist:"user/accepttask_wenshulist.html",//监管人员---立即执行任务-- 行政执法规范行文书现场记录表
	accepttask_questionslist:"user/accepttask_questionslist.html",//监管人员---立即执行任务-- 一般问题
	accepttask_recordlist:"user/accepttask_recordlist.html",//监管人员---立即执行任务-- 现场笔录

	ele_manage: "admindata/elevator_manage.html",  //电梯使用单位-电梯管理
	weibao_man: "weibao/elevator_manage.html",  //维保单位-电梯管理
	weibao_detail: "weibao/elevator_maintain_detail.html", //维保单位-保养任务列表--电梯详情
	weibao_status: "weibao/elevator_status.html", //维保单位-电梯管理-设置状态提交
	weibao_add: "weibao/maintain_add.html",  //维保单位-保养任务-保养提交
	ele_state: "admindata/elevator_detail.html",  //电梯使用单位-电梯管理--详情
	send_state: "admindata/elevator_status.html",  //电梯使用单位-电梯管理-设置状态提交
	ele_list_detail: "user/taskother_detail.html", //使用单位-任务确认--其他列表详情
	ele_submit: "user/taskother_autograph.html",  //使用单位-任务确认-其他列表-签名
	send_inspic:"admindata/elevator_check.html",  //电梯使用单位-电梯每日巡查详情-提交
	inspiction: "admindata/elevator_detail_daily.html",  //电梯使用单位-电梯每日巡查详情
	un_review: "user/checklist.html",  //18、监管人员---其他（未审核待审核已完成）
	un_read: "user/unreadmessages.html", //22、监管人员---未读消息
	archive: "weibao/user_list.html", //43、维保单位-人员档案列表
	user_dele: "weibao/user_del.html", //44、维保单位-人员档案列表-人员档案删除
	user_detail: "weibao/user_detail.html", //45、维保单位-人员档案--详情
	list_table: "weibao/weibao_paln.html", //50、维保单位-维保计划列表
	duty_details: "user/checklist_detail.html",//19、监管人员---其他（未审核待审核已完成）-详情
	message_detail: "user/messagesdetail.html", //24、未读消息-详情

	modifydetail:"admindata/modifydetail.html",//电梯使用单位-待整改详情
	modifyautograph:"admindata/modifyautograph.html",//电梯使用单位-待整改详情-检查完成
	taskdetail:"admindata/taskdetail.html",//电梯使用单位-监管任务详情
	taskautograph:"admindata/taskautograph.html",//电梯使用单位-监管任务-检查完成确认
	
	clauselist:"user/clauselist.html",//(特种设备安全法)列表
	clausedetail:"user/clausedetail.html",// （特种设备安全法）详情

	sendImg: "user/basesave.html",  //54、上传签名base64图片
	getImg: "user/getautograph.html" //7、获取用户签名
}
//截取参数
function GetRequest() {
	var url = location.search;
	//获取url中"?"符后的字串
	var theRequest = new Object();
	if (url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for (var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest;
}
//判断是否是安卓还是ios
function isAndroid_ios(){
	var u = navigator.userAgent, app = navigator.appVersion;
	var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //android终端或者uc浏览器
	var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	return isAndroid==true?true:false;
}

function back(){
	console.log(isAndroid_ios())
    if(isAndroid_ios()){
        //安卓
		JsToAppObject.closeController();
    }else{
		//ios
		window.webkit.messageHandlers.JsToAppObject.postMessage({"key":"closeController"})
    }
}

function sendPic(img){
	var msgs = ''  
	$.ajax({
		url: requestUrl + api.sendImg,
			headers: {
				Accept: "application/json; charset=utf-8"
			},
			data: { base64_image_content: img},
			type: 'post',
			dataType: 'json',
			async:false,
			success: function (res) {
				if(res.code == 1){	
					msgs = res.data.src;
					//return msgs;
				}else{
					alert(res.msg);
					return '';
				}		 
			}  
	})
	return msgs;
}

 window.alert = function(name){
            var iframe = document.createElement("IFRAME");
            iframe.style.display="none";
            iframe.setAttribute("src", 'data:text/plain,');
            document.documentElement.appendChild(iframe);
            window.frames[0].window.alert(name);
            iframe.parentNode.removeChild(iframe);
        };
