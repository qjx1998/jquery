var apikey,id,bhid;
$(function(){
    //获取当前页面参数和apikey
    var theRequest = GetRequest();
    id = theRequest.id;
    apikey = theRequest.apikey;
    category_type = theRequest.category_type
    // alert(category_type)
    //获取任务详情
    taskdetail()

})


//电梯使用单位-待整改详情
function taskdetail(){
    $.ajax({
        type:"post",
        url :requestUrl+api.message_detail,
        data:{
            id: id,
            category_type: category_type
        },
        headers:{
            apikey: apikey,
            Accept: "application/json; charset=utf-8"
        },
        async: true,
        dataType: "json",
        success: function(data){
            console.log(data,"电梯使用单位-待整改详情")
            if(data.code==1){
                var res = data.data;
                bhid = res.id;
                var date = new Date(res.recorddate*1000);
                var recordy = date.getFullYear();
                var recordm = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1);
                var recordd = (date.getDate() < 10 ? '0'+date.getDate() : date.getDate());
                $("input[name='type_id']").val(res.checkinfo.type_id)
                $("input[name='equipment_type']").val(res.checkinfo.equipment_type)
                $(":radio[name='check_type'][value='" + res.checkinfo.check_type + "']").prop("checked", "checked");
                $(":radio[name='check_id'][value='" + res.checkinfo.check_id + "']").prop("checked", "checked");
                $("textarea[name='check_text']").val(res.checkinfo.check_text)
                $("textarea[name='register_code']").val(res.checkinfo.register_code)
                $(":radio[name='is_question1'][value='" + res.checkinfo.is_question1 + "']").prop("checked", "checked");
                $("textarea[name='is_question1_text']").val(res.checkinfo.is_question1_text)
                $(":radio[name='is_question2'][value='" + res.checkinfo.is_question2 + "']").prop("checked", "checked");
                $("textarea[name='is_question2_text']").val(res.checkinfo.is_question2_text)
                $(":radio[name='is_question3'][value='" + res.checkinfo.is_question3 + "']").prop("checked", "checked");
                $("textarea[name='is_question3_text']").val(res.checkinfo.is_question3_text)
                $(":radio[name='is_question4'][value='" + res.checkinfo.is_question4 + "']").prop("checked", "checked");
                $("textarea[name='is_question4_text']").val(res.checkinfo.is_question4_text)
                $(":radio[name='is_question5'][value='" + res.checkinfo.is_question5 + "']").prop("checked", "checked");
                $("textarea[name='is_question5_text']").val(res.checkinfo.is_question5_text)
                $(":radio[name='is_question6'][value='" + res.checkinfo.is_question6 + "']").prop("checked", "checked");
                $("textarea[name='is_question6_text']").val(res.checkinfo.is_question6_text)
                $(":radio[name='is_question7'][value='" + res.checkinfo.is_question7 + "']").prop("checked", "checked");
                $("textarea[name='is_question7_text']").val(res.checkinfo.is_question7_text)
                $(":radio[name='is_question8'][value='" + res.checkinfo.is_question8 + "']").prop("checked", "checked");
                $("textarea[name='is_question8_text']").val(res.checkinfo.is_question8_text)
                $(":radio[name='is_question9'][value='" + res.checkinfo.is_question9 + "']").prop("checked", "checked");
                $("textarea[name='is_question9_text']").val(res.checkinfo.is_question9_text)
                $(":radio[name='is_question10'][value='" + res.checkinfo.is_question10 + "']").prop("checked", "checked");
                $("textarea[name='is_question10_text']").val(res.checkinfo.is_question10_text)
                $("textarea[name='supplement']").val(res.checkinfo.supplement)
                $("textarea[name='measures']").val(res.checkinfo.measures)
                $("input[name='recordautograph']").val(res.checkinfo.recordautograph)

                $('.opinion').val(res.checkinfo.opinion);

                // $("input[name='recorddate']").val(res.recorddate)
                $("#recordy").val(recordy)
                $("#recordm").val(recordm)
                $("#recordd").val(recordd)
                $("input[name='stardate']").val(res.stardate)
                $("input[name='enddate']").val(res.enddate)
                $("input[name='company']").val(res.company)
                $("input[name='companyaddress']").val(res.companyaddress)
                $("input[name='legalname']").val(res.legalname)
                $("input[name='linkname']").val(res.linkname)
                $("input[name='linkmobile']").val(res.linkmobile)
                $("input[name='linkpost']").val(res.linkpost)

                $("#num").html(res.num)
                $("#usecargo").html(res.usecargo)
                $("#useescalator").html(res.useescalator)
                $("#useelevator").html(res.useelevator)
                $("#usesidewalk").html(res.usesidewalk)
                $("#stopcargo").html(res.stopcargo)
                $("#stopescalator").html(res.stopescalator)
                $("#stoplevator").html(res.stoplevator)
                $("#stopsidewalk").html(res.stopsidewalk)

                $('.times1').html(res.checkinfo.autographdate);
                $('.times2').html(res.checkinfo.recorddate);

                $("#total").html(res.num)
                $('#image').html('<img src="' + res.checkinfo.autograph + '" height="100px">');

                $("#checkautograph").val(res.checkinfo.checkautograph);
                var i = new Image();
                i.src = res.checkinfo.checkautograph;
                $(i).appendTo($("#image2"))


                $("#recordautograph").val(res.checkinfo.recordautograph)
                var i = new Image();
                i.src = res.checkinfo.recordautograph;
                $(i).appendTo($("#image3")) // append the image (SVG) to DOM.

            }else{
                alert("获取失败："+data.msg)
            }

        }
    })
}