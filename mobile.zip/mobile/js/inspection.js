var apikey,id="";

$(function () {
    var theRequest = GetRequest();
    apikey = theRequest.apikey;
    id = theRequest.id;
    getData();
})

function getData() {
    $.ajax({
        url: requestUrl + api.inspiction,
        headers: {
            apikey: apikey,
            Accept: "application/json; charset=utf-8"
        },
        data: { id: id },
        type: 'post',
        dataType: 'json',
        success: function (res) {
          let data = res.data;
          if(data){
              $('.names').html(data.name);
              $('.elv-code').html(data.numberno);
              $('.elv-place').html(data.security_useaddress);
              $('.elv-sta').html(data.status);
              $('.timers').html(data.creattime);
          }
        }
    })
}