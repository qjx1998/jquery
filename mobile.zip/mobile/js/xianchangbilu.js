var apikey,id;
$(function(){
	//获取当前页面参数和apikey
	var theRequest =GetRequest();
	id = theRequest.id;
	apikey = theRequest.apikey;
	category_type = theRequest.category_type;
	//获取任务详情
	task_detail()
})

//监管人员---立即执行任务-- 现场笔录
var recordlist;
function accepttask_recordlist(){
	var startdate = $("#starty").val()+'/'+$("#startm").val()+'/'+$("#startd").val()+' '+$("#starth").val()+':'+$("#startmi").val()+':00'
	var time = Date.parse(new Date(startdate))/1000;
	$("#startdate").val(time);
	var enddate = $("#endy").val()+'/'+$("#endm").val()+'/'+$("#endd").val()+' '+$("#endh").val()+':'+$("#endmi").val()+':00'
	var time1 = Date.parse(new Date(enddate))/1000;
	$("#enddate").val(time1)
	
	
	var date1 = $("#py").val()+'/'+$("#pm").val()+'/'+$("#pd").val()
	var time3 = Date.parse(new Date(date1))/1000;
	$("#partydate").val(time3);
	
	var date2 = $("#wy").val()+'/'+$("#wm").val()+'/'+$("#wd").val()
	var time4 = Date.parse(new Date(date2))/1000;
	$("#witnessdate").val(time4)
	
	var date3 = $("#autographdate_year").val()+'/'+$("#autographdate_month").val()+'/'+$("#autographdate_day").val()
	var time5=Date.parse(new Date(date3))/1000;
	$("#checkdate").val(time5)
	
	var formObject = {};
	var list = {};
	var flag=1;
	var formArray =$("#bilu").serializeArray();
	$.each(formArray,function(i,item){
		formObject[item.name] = item.value;
		if(item.value==""){
			flag=0
			if(item.name=="partyautograph"||item.name=="witnessautograph"||item.name=="checkautograph"){
				alert("请确认签名")
			}else{
				alert("请填写完整数据")
			}
			return false;
		}
	});
	if(flag==1){
		formObject.task_id=id;
		list["recordlist"] = formObject
		console.log(formObject)
		recordlist=JSON.stringify(list)
		console.log("recordlist",recordlist)
		
		$.ajax({
			type:"post",
			url :requestUrl+api.accepttask_recordlist,
			data:{
				id:id,
				category_type:category_type,
				recordlist:recordlist	
			},
			headers:{
				apikey:apikey,
				Accept: "application/json; charset=utf-8"
			},
			async: true,
			dataType: "json",
			success: function(data){
				console.log(data,"检查记录提交")
				if(data.code==1){
					alert("提交成功");
					back()
				}else{
					alert("提交失败："+data.msg)
				}
			},
			error:function(error){
				alert("提交失败："+error.msg)
			}
		})
	}
}

//监管人员---任务详情
function task_detail(){
	$.ajax({
		type:"post",
		url :requestUrl+api.task_detail,
		data:{
			id:id
		},
		headers:{
			apikey:apikey,
			Accept: "application/json; charset=utf-8"
		},
		async: true,
		dataType: "json",
		success: function(data){
			console.log(data,"任务详情")
			if(data.code==1){
				var res = data.data;
				$("input[name='stardate']").val(res.stardate)
				$("input[name='enddate']").val(res.enddate)
				$("input[name='address']").val(res.address)
				$("input[name='checkname']").val(res.checkname)
				$("input[name='checkname1']").val(res.checkname1)
				$("input[name='checknameno']").val(res.checknameno)
				$("input[name='checknameno1']").val(res.checknameno1)
				$("input[name='companyaddress']").val(res.companyaddress)
				$("input[name='legalname']").val(res.legalname)
				$("input[name='linkmobile']").val(res.linkmobile)
				$("input[name='linkaddress']").val(res.companyaddress)
			}
			
		}
	})
}